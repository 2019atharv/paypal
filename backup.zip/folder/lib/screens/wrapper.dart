import 'package:flutter/material.dart';
import 'package:paypal/screens/onboarding.dart';

class Wrapper extends StatelessWidget {
  

  @override
  Widget build(BuildContext context) {
    return Onboarding();
  }
}